# Platform Support Matrix

> **Status**: UPDATED with CentOS 7.9 ISO authoritative baseline
> **Last Updated**: 2026-07-22
> **Principle**: A platform is SUPPORTED only after passing full offline acceptance on real hardware.

---

## 1. Platform Status Summary

| Platform | Data Source | Build | Dep Closure | Offline Install | SQL | Restart | OS Reboot | Idempotent | Status |
|----------|------------|-------|------------|-----------------|-----|---------|-----------|------------|--------|
| centos-7.9-x86_64 | ✅ ISO + VM | — | — | — | — | — | — | — | **UNVERIFIED** |
| centos-7.8-x86_64 | ❌ None | — | — | — | — | — | — | — | **UNVERIFIED** |
| tencentos-2.4-x86_64 | ❌ None | — | — | — | — | — | — | — | **UNVERIFIED** |
| tencentos-3.1-x86_64 | ❌ None | — | — | — | — | — | — | — | **UNVERIFIED** |
| kylin-v10-aarch64 | ❌ None | — | — | — | — | — | — | — | **UNVERIFIED** |

---

## 2. Detailed Platform Environment Specifications

### 2.1 centos-7.9-x86_64

```
Status:               UNVERIFIED
ISO Available:        ✅ E:\镜像\CentOS-7-x86_64-DVD-2009 (1).iso (4.7 GB)
ISO Date:             2020-10-29 (CentOS 7.9 GA)
VM Available:         ✅ Running at 192.168.44.129 (16 vCPU, 16 GB RAM)
VM Access:            ❌ Root password unknown
Packages on ISO:      4,070
@core Group:          86 packages

Authoritative Package Versions (from ISO):
  glibc:              2.17-317.el7
  kernel:             3.10.0-1160.el7
  systemd:            219-78.el7
  gcc:                4.8.5-44.el7          ← TOO OLD for MySQL 8.0
  cmake:              2.8.12.2-2.el7        ← TOO OLD for MySQL 8.0
  openssl-libs:       1.0.2k-19.el7
  rpm:                4.11.3-45.el7
  bash:               4.2.46-34.el7
  libstdc++:          4.8.5-44.el7
  libcurl:            7.29.0-59.el7

Build Toolchain Required:
  GCC:                devtoolset-8 (GCC 8.3.1) — NOT on ISO
  CMake:              cmake3 ≥ 3.11 — NOT on ISO (from EPEL)
  Boost:              1.77.0 (TBD from TXSQL source)

Platform-Specific Notes:
  - yum only (no dnf)
  - createrepo (NOT createrepo_c)
  - systemd 219 — fewer directives than 239+
  - glibc 2.17 — OLDEST of all targets → MUST be build host for x86_64
  - /etc/os-release: ID="centos", VERSION_ID="7"
  - centos-release RPM: centos-release-7-9.2009.0.el7.centos.x86_64
```

### 2.2 centos-7.8-x86_64

```
Status:               UNVERIFIED
ISO Available:        ❌
VM Available:         ❌ None found
Expected glibc:       2.17 (same as 7.9)
Expected systemd:     219 (earlier release than 7.9)
Expected kernel:      3.10.0-1127.el7
Key Unknowns:         Exact glibc release, systemd release, rpm release
```

### 2.3 tencentos-2.4-x86_64

```
Status:               UNVERIFIED
ISO Available:        ❌
VM Available:         ❌ None found
Expected Base:        RHEL 7 / CentOS 7
Expected glibc:       2.17
Expected PKG MGR:     yum (likely)
Key Unknowns:         OS ID ('tencentos' vs 'tlinux'), OpenSSL vs Tencentsm,
                      kernel type, SELinux default
Risk:                 Tencentsm (国密) may replace standard OpenSSL
```

### 2.4 tencentos-3.1-x86_64

```
Status:               UNVERIFIED
ISO Available:        ❌
VM Available:         ❌ None found
Expected Base:        RHEL 8 / CentOS 8
Expected glibc:       2.28
Expected PKG MGR:     dnf (likely)
Expected systemd:     239+
Key Unknowns:         Same as 2.4, plus DNF modularity impact,
                      createrepo_c vs createrepo
Binary Compat:        CentOS 7 binary SHOULD work on glibc 2.28 (forward compat)
```

### 2.5 kylin-v10-aarch64

```
Status:               UNVERIFIED
Environment:          ❌ No aarch64 hardware available
Build:                MUST be native aarch64 (no cross-compilation)
SP Version:           UNDETERMINED (SP1/SP2/SP3)
Expected CPU:         Kunpeng 920 or Phytium FT-2000+
Expected Base:        openEuler / RHEL 8
Key Unknowns:         glibc version, GCC version, OpenSSL variant,
                      package manager (dnf likely), systemd version,
                      SELinux policy, RPM ABI
```

---

## 3. 24-Point Acceptance Test Checklist

Each platform must pass ALL tests before being marked SUPPORTED:

| # | Test | Description |
|---|------|-------------|
| 1 | Fresh offline install | Clean OS, no network, `sudo ./install.sh </dev/null` |
| 2 | No interaction | Zero prompts, zero `read` calls |
| 3 | systemd active | `systemctl is-active txsql` returns `active` |
| 4 | mysqld as txsql | `ps aux` shows mysqld running as `txsql` |
| 5 | All ELF resolved | No `not found` in `ldd` for any ELF |
| 6 | SQL read/write | CREATE/INSERT/SELECT/UPDATE/COMMIT |
| 7 | systemctl restart | Restart succeeds |
| 8 | Data survives restart | Data readable after restart |
| 9 | OS reboot | Full OS reboot, txsql auto-starts |
| 10 | Auto-start after reboot | `systemctl is-active txsql` returns `active` |
| 11 | Repeat install idempotent | No data loss, exits 0 |
| 12 | Credentials unchanged | `/root/.txsql_credentials` unchanged |
| 13 | Uninstall preserves data | Data intact after default uninstall |
| 14 | Reinstall recognizes data | Existing data detected after reinstall |
| 15 | Port conflict detected | Clean exit with message |
| 16 | Existing MySQL detected | Clean exit with message |
| 17 | Non-empty datadir | Clean exit with message |
| 18 | Missing RPM | Clean exit, no partial install |
| 19 | Corrupt RPM | SHA-256 failure → exit before touching system |
| 20 | SHA-256 error | Tampered file → verify-media fails |
| 21 | Disk space | Precheck fails → clear message |
| 22 | SELinux enforcing | Install completes or exits with SELinux guidance |
| 23 | No passwords in logs | Zero hits grepping for password |
| 24 | No online requests | Zero outbound connections during install |

---

## 4. Build Strategy Implementation

### Strategy A: Common x86_64 Binary

```
Build Host:    CentOS 7.8 or 7.9 (glibc 2.17 baseline)
Toolchain:     devtoolset-8 (GCC 8.3.1) + cmake3 (EPEL)
Targets:       All 4 x86_64 platforms

Decision Flow:
  Build on CentOS 7.9
    └─ Test on CentOS 7.9    → PASS? ✅
       └─ Test on CentOS 7.8 → PASS? (Very likely — same glibc)
          └─ Test on TencentOS 2.4 → PASS? (Likely — RHEL 7 based)
             └─ Test on TencentOS 3.1 → PASS? (Should — glibc forward compat)
                ├─ ALL PASS → Strategy A CONFIRMED
                └─ ANY FAIL → Strategy B for that platform
```

### Strategy B: Per-Platform Build (Fallback Only)

Only activated if Strategy A fails. Build independently on the failing platform.

### Strategy C: Kylin V10 aarch64 (Independent)

Always native aarch64 build. No crossover with x86_64 strategy.

---

## 5. Dependency Matrix (CentOS 7.9 Baseline — Authoritative)

| Dependency | CentOS 7.9 ISO | Notes |
|------------|---------------|-------|
| glibc | 2.17-317.el7 | Build floor; NEVER bundle |
| libstdc++ | 4.8.5-44.el7 | From GCC 4.8.5; static-link or bundle from devtoolset |
| libgcc_s | 4.8.5-44.el7 | Static-link or bundle from devtoolset |
| OpenSSL libs | 1.0.2k-19.el7 | EOL; may need to bundle 1.1.1 |
| libcurl | 7.29.0-59.el7 | System RPM |
| ncurses-libs | 5.9-14.20130511.el7_4 | System RPM |
| libaio | 0.3.109-13.el7 | System RPM |
| cyrus-sasl-lib | 2.1.26-23.el7 | System RPM |
| openldap | 2.4.44-22.el7 | System RPM |
| libtirpc | 0.2.4-0.16.el7 | System RPM |
| numactl-libs | 2.0.12-5.el7 | System RPM |
| zlib | 1.2.7-18.el7 | System RPM |
| lz4 | 1.8.3-1.el7 | MySQL bundles; use bundled |
| pam | 1.1.8-23.el7 | System — never bundle |
| systemd | 219-78.el7 | System — never bundle |
| rpm | 4.11.3-45.el7 | System — never bundle |
| bash | 4.2.46-34.el7 | System — never bundle |

---

## 6. Update History

| Date | Change |
|------|--------|
| 2026-07-22 | Initial matrix created |
| 2026-07-22 | CentOS 7.9 ISO analyzed — authoritative baseline established |
| 2026-07-22 | 13 VMware VMs enumerated; 3 running but inaccessible |
| 2026-07-22 | Build toolchain gap analysis completed (GCC, CMake, Boost gaps identified) |
| 2026-07-22 | Compatibility strategy defined: CentOS 7.9 as x86_64 build baseline |
